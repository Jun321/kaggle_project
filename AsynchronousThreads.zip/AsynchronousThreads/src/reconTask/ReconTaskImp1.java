package reconTask;

import java.util.concurrent.TimeUnit;

/** 
 * @author  作者 E-mail: 
 * @date 创建时间：2016-7-23 下午11:02:04 
 * @version 1.0 
 */
public class ReconTaskImp1 extends ReconTask{
	
	public ReconTaskImp1(long runtime) {
		super(runtime);
	}

	@Override
	public void execute() {
		try {
			System.out.println(String.format("The LoadTaskImp1 is running in %s seconds.", runtime));
			TimeUnit.SECONDS.sleep(runtime);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
