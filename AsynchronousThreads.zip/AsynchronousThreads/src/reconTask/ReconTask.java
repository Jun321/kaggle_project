package reconTask;

/** 
 * @author  作者 E-mail: 
 * @date 创建时间：2016-7-23 下午10:55:00 
 * @version 1.0 
 */
public abstract class ReconTask implements Runnable{
	protected long runtime;
	
	public ReconTask(long runtime){
		this.runtime = runtime;
	}
	
	public abstract void execute();
	
	@Override
	public void run() {
		execute();
	}
	
}
