package ThreadPool;

import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

public class ThreadPoolManager{
	private static final BaseThreadPool LoadThreadPool = new BaseThreadPool(5, 5, 2, TimeUnit.SECONDS, new LinkedBlockingQueue<Runnable>());
	private static final BaseThreadPool ReconThreadPool = new BaseThreadPool(5, 5, 2, TimeUnit.SECONDS, new LinkedBlockingQueue<Runnable>());
	
	private ThreadPoolManager(){}
	
	public static BaseThreadPool getLoadThreadPool(){
		return LoadThreadPool;
	}
	
	public static BaseThreadPool getReconThreadPool(){
		return ReconThreadPool;
	}
}
