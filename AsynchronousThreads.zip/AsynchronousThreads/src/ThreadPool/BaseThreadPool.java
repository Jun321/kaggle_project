package ThreadPool;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public class BaseThreadPool {
	private int corePoolSize, maximumPoolSize;
	private long keepAliveTime;
	private TimeUnit unit;
	private BlockingQueue<Runnable> queue;
	private ThreadPoolExecutor executor;
	
	public BaseThreadPool(int cs, int maxs, long kat, TimeUnit unit, BlockingQueue<Runnable> queue){
		this.corePoolSize = cs;
		this.maximumPoolSize = maxs;
		this.keepAliveTime = kat;
		this.unit = unit;
		this.queue = queue;
		this.executor = new ThreadPoolExecutor(this.corePoolSize, this.maximumPoolSize, this.keepAliveTime, this.unit, this.queue);
	}
	
	public void executeTask(Runnable task){
		executor.execute(task);
	}
	
	public String getThreadPoolInfo(){
		return  String.format("[monitor] [%d/%d] Active: %d, Completed: %d, Task: %d, isShutdown: %s, isTerminated: %s",
                this.executor.getPoolSize(),
                this.executor.getCorePoolSize(),
                this.executor.getActiveCount(),
                this.executor.getCompletedTaskCount(),
                this.executor.getTaskCount(),
                this.executor.isShutdown(),
                this.executor.isTerminated());
	}
}
