package loadController;

import loadTask.LoadTask;

/** 
 * @date 创建时间：2016-7-23 下午2:08:34 
 * @version 1.0 
 * @author Jun
 */
public class LoadController{
	private static final LoadRule rule = LoadRule.getInstance();
	
	private LoadController(){}
	
	public static void notifyComplete(LoadTask task) {
		rule.notifyComplete(task);
	}

	public static void addTask(LoadTask task) {
		rule.addTask(task);
	}
	
	public static void startTasks(String key){
		rule.startTasks(key);
	}
}
