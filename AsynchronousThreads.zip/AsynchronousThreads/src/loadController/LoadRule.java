package loadController;

import java.util.Map;
import java.util.Queue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;

import test.Const;

import ThreadPool.BaseThreadPool;
import ThreadPool.ThreadPoolManager;
import loadTask.LoadState;
import loadTask.LoadTask;

/** 
 * @date 创建时间：2016-7-23 下午2:08:34 
 * @version 1.0 
 * @author Jun
 */
public class LoadRule {
	
	private static final BaseThreadPool loadThreadPool = ThreadPoolManager.getLoadThreadPool();
	private static final Map<String, ConcurrentLinkedQueue<LoadTask>> loadTasksMap = new ConcurrentHashMap<String, ConcurrentLinkedQueue<LoadTask>>();
	
	private static final LoadRule INSTANCE = new LoadRule();
	private LoadRule(){}
	
	public static LoadRule getInstance(){
		return INSTANCE;
	}
	
	public void addTask(LoadTask task){
		String taskKey = task.getTicket().getGroupKey();
		ConcurrentLinkedQueue<LoadTask> tasks = loadTasksMap.get(taskKey);
		if(tasks == null){
			ConcurrentLinkedQueue<LoadTask> queue = new ConcurrentLinkedQueue<LoadTask>();
			queue.add(task);
			loadTasksMap.put(taskKey, queue);
		}else{
			loadTasksMap.get(taskKey).add(task);
		}
	}

	public void notifyComplete(LoadTask task) {
		Queue<LoadTask> groupTasks = loadTasksMap.get(task.getTicket().getGroupKey());
		switch(task.getTicket().getLabel()){
		case Const.LOADTASK1:
			task1Notify(groupTasks);
			break;
		case Const.LOADTASK2:
			task2Notify(groupTasks);
			break;
		case Const.LOADTASK3:
			task3Notify(groupTasks);
			break;
		case Const.LOADTASK4:
			task4Notify(groupTasks);
			break;
		default:
			break;
		}
	}
	
	public void startTasks(String key) {
		ConcurrentLinkedQueue<LoadTask> queue = loadTasksMap.get(key);
		for (LoadTask task : queue){
			if (task.getTicket().getLoadState() == LoadState.LoadStartImmediately)
				loadThreadPool.executeTask(task);
		}
	}
	
	private void task4Notify(Queue<LoadTask> groupTasks) {
		if (isTotalTaskComplete(groupTasks)){
			String key = groupTasks.poll().getTicket().getGroupKey();
			loadTasksMap.remove(key);
			System.out.println(String.format("total load process complete. key: %s", groupTasks.poll().getTicket().getGroupKey()));
			System.out.println(loadTasksMap);
		}
	}
	
	private void task3Notify(Queue<LoadTask> groupTasks) {
		LoadTask task = getSpecificTask(Const.LOADTASK4, groupTasks);
		loadThreadPool.executeTask(task);
	}
	
	private void task2Notify(Queue<LoadTask> groupTasks) {
		LoadTask task = getSpecificTask(Const.LOADTASK3, groupTasks);
		loadThreadPool.executeTask(task);
	}

	private void task1Notify(Queue<LoadTask> groupTasks){
		if (isTotalTaskComplete(groupTasks)){
			String key = groupTasks.poll().getTicket().getGroupKey();
			loadTasksMap.remove(key);
			System.out.println(String.format("total load process complete. key: %s", groupTasks.poll().getTicket().getGroupKey()));
			System.out.println(loadTasksMap);
		}
	}
	
	private boolean isTotalTaskComplete(Queue<LoadTask> groupTasks){
		if(groupTasks.size() == Const.LOADTASKSIZE ){
			boolean flag = true;
			for(LoadTask s : groupTasks){
				boolean tmp = isTaskComplete(s);
				flag = flag && tmp;
			}
			return flag;
		}
		return false;
	}
	
	private boolean isTaskComplete(LoadTask task){
		LoadState state = task.getTicket().getLoadState();
		return state == LoadState.LoadSuccess || state == LoadState.LoadError;
	}
	
	private LoadTask getSpecificTask(String label, Queue<LoadTask> groupTasks){
		LoadTask task = null;
		for (LoadTask s : groupTasks){
			if (s.getTicket().getLabel() == label)
				task = s;
		}
		if (task == null)
			System.out.println(String.format("ERROR when get specific label task %s", label));
		
		return task;
	}
}
