package test;

import loadController.LoadController;
import loadTask.LoadTaskImp1;
import loadTask.LoadTaskImp2;
import loadTask.LoadTaskImp3;
import loadTask.LoadTaskImp4;

/** 
 * @date 创建时间：2016-7-23 下午2:08:34 
 * @version 1.0 
 * @author Jun
 */
public class Main {
	public static void main(String[] args) {
		for (int i = 0; i < 5; i++){
			String key = String.format("LOADGROUPTASKS-%s", i);
			LoadTaskImp1 load1 = new LoadTaskImp1((int)(Math.random()*10), key);
			LoadTaskImp2 load2 = new LoadTaskImp2((int)(Math.random()*10), key);
			LoadTaskImp3 load3 = new LoadTaskImp3((int)(Math.random()*10), key);
			LoadTaskImp4 load4 = new LoadTaskImp4((int)(Math.random()*10), key);
			LoadController.addTask(load1);
			LoadController.addTask(load2);
			LoadController.addTask(load3);
			LoadController.addTask(load4);
			LoadController.startTasks(key);
		}
	}
}
