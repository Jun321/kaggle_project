package test;
public class Const {
	public static final String LOADTASK1 = "LoadTaskImp1";
	public static final String LOADTASK2 = "LoadTaskImp2";
	public static final String LOADTASK3 = "LoadTaskImp3";
	public static final String LOADTASK4 = "LoadTaskImp4";
	
	public static final int LOADTASKSIZE = 4;
}
