package loadTask;

import loadController.LoadController;

/** 
 * @author  作者 E-mail: 
 * @date 创建时间：2016-7-23 下午10:55:00 
 * @version 1.0 
 */
public abstract class LoadTask implements Runnable{
	protected long runtime;
	protected LoadTaskTicket ticket;
	
	public LoadTask(long runtime, String groupKey, String label){
		this.runtime = runtime;
		this.ticket = new LoadTaskTicket(groupKey, label);
	}
	
	public abstract void execute();
	
	@Override
	public void run() {
		execute();
		notifyController();
	}
	
	public LoadTaskTicket getTicket(){
		return ticket;
	}
	
	private void notifyController(){
		LoadController.notifyComplete(this);
	}
}
