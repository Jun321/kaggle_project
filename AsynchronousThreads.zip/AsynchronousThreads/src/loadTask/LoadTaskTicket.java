package loadTask;


/** 
 * @author  作者 E-mail: 
 * @date 创建时间：2016-7-23 下午10:55:00 
 * @version 1.0 
 */
public class LoadTaskTicket {
	private String groupKey;
	private String label;
	private LoadState state;
	
	public LoadTaskTicket(String groupKey, String label){
		this.groupKey = groupKey;
		this.label = label;
	}
	
	public void setLoadState(LoadState state){
		this.state = state;
	}
	
	public String getGroupKey(){
		return groupKey;
	}
	
	public String getLabel(){
		return label;
	}
	
	public LoadState getLoadState(){
		return state;
	}
}
