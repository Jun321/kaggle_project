package loadTask;

import java.util.concurrent.TimeUnit;


import test.Const;

/** 
 * @author  作者 E-mail: 
 * @date 创建时间：2016-7-23 下午11:02:04 
 * @version 1.0 
 */
public class LoadTaskImp4 extends LoadTask{
	private static final String taskLabel = Const.LOADTASK4;
	public LoadTaskImp4(long runtime, String key) {
		super(runtime, key, taskLabel);
		ticket.setLoadState(LoadState.LoadStartDelayed);
	}
	
	@Override
	public void execute() {
		try {
			ticket.setLoadState(LoadState.LoadProcessing);
			System.out.println(String.format("The %s(%s) is running in %s seconds.", taskLabel, this.ticket.getGroupKey(),  runtime));
			TimeUnit.SECONDS.sleep(runtime);
			ticket.setLoadState(LoadState.LoadSuccess);
			System.out.println(String.format("The %s(%s) is completed.", taskLabel, this.ticket.getGroupKey()));
		} catch (InterruptedException e) {
			ticket.setLoadState(LoadState.LoadError);
			e.printStackTrace();
		}
	}
}
