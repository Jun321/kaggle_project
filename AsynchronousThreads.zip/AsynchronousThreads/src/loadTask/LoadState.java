package loadTask;
/** 
 * @author  作者 E-mail: 
 * @date 创建时间：2016-7-23 下午10:13:18 
 * @version 1.0 
 */
public enum LoadState {
	LoadStartImmediately,
	LoadStartDelayed,
	LoadProcessing,
	LoadSuccess,
	LoadError
}
