/*
 * 
 * BackDatedThreadPool	Jul 25, 2016
 * Copyright (c) 2006 State Street Technology(Zhejiang) Co.,Ltd.
 * All rights reserved.
 * 
 */
package backDate;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * @Description: TODO
 * @author e604294
 */

public class BackDatedThreadPool {
    private int corePoolSize, maximumPoolSize;
    private long keepAliveTime;
    private TimeUnit unit;
    private BlockingQueue<Runnable> queue;
    private static ThreadPoolExecutor executor;
    private static BackDatedThreadPool bd;
    
    private BackDatedThreadPool(int cs, int maxs, long kat, TimeUnit unit, BlockingQueue<Runnable> queue){
        this.corePoolSize = cs;
        this.maximumPoolSize = maxs;
        this.keepAliveTime = kat;
        this.unit = unit;
        this.queue = queue;
        BackDatedThreadPool.executor = new ThreadPoolExecutor(this.corePoolSize, this.maximumPoolSize, this.keepAliveTime, this.unit, this.queue);
    }
    
    public void executeTask(Runnable task){
        executor.execute(task);
    }
    
    public static synchronized BackDatedThreadPool getInstance(){
        if (bd == null){
            int cs = 5; 
            int maxs = 10; 
            long kat = 5; 
            TimeUnit unit = TimeUnit.SECONDS;
            BlockingQueue<Runnable> queue = new LinkedBlockingQueue<Runnable>();
            bd = new BackDatedThreadPool(cs, maxs, kat, unit, queue);
            return bd;
        }
        return bd;
    }
    
    public String getThreadPoolInfo(){
        if (BackDatedThreadPool.executor != null){
            return  String.format("[monitor] [%d/%d] Active: %d, Completed: %d, Task: %d, isShutdown: %s, isTerminated: %s",
                    BackDatedThreadPool.executor.getPoolSize(),
                    BackDatedThreadPool.executor.getCorePoolSize(),
                    BackDatedThreadPool.executor.getActiveCount(),
                    BackDatedThreadPool.executor.getCompletedTaskCount(),
                    BackDatedThreadPool.executor.getTaskCount(),
                    BackDatedThreadPool.executor.isShutdown(),
                    BackDatedThreadPool.executor.isTerminated());
        }
        return null;
    }
}
