/*
 * 
 * BackDatedThreadPool	Jul 25, 2016
 * Copyright (c) 2006 State Street Technology(Zhejiang) Co.,Ltd.
 * All rights reserved.
 * 
 */
package backDate;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import backDate.controller.BackDatedController;

/**
 * @Description: TODO
 * @author e604294
 */

public class BackDatedThreadPool extends ThreadPoolExecutor{
    private static BackDatedThreadPool bd;
    
    private static final int poolSize = 10;
    
    private BackDatedThreadPool(int cs, int maxs, long kat, TimeUnit unit, BlockingQueue<Runnable> queue){
        super(cs, maxs, kat, unit, queue);
    }
    
    @Override
    protected void beforeExecute(Thread paramThread, Runnable paramRunnable) {
        
    }



    @Override
    protected void afterExecute(Runnable paramRunnable, Throwable paramThrowable) {
        if (paramRunnable instanceof BackDateTask)
            BackDatedController.notifyComplete((BackDateTask)paramRunnable);
    }



    public void executeTask(Runnable task){
        
        this.execute(task);
    }
    
    public static synchronized BackDatedThreadPool getInstance(){
        if (bd == null){
            int cs = poolSize; 
            int maxs = poolSize; 
            long kat = 5; 
            TimeUnit unit = TimeUnit.SECONDS;
            BlockingQueue<Runnable> queue = new LinkedBlockingQueue<Runnable>();
            bd = new BackDatedThreadPool(cs, maxs, kat, unit, queue);
            return bd;
        }
        return bd;
    }
    
    
    public int getMaxPoolSize(){
        return poolSize;
    }
    
    public String getThreadPoolInfo(){
        return  String.format("[monitor] [%d/%d] Active: %d, Completed: %d, Task: %d, isShutdown: %s, isTerminated: %s",
                this.getPoolSize(),
                this.getCorePoolSize(),
                this.getActiveCount(),
                this.getCompletedTaskCount(),
                this.getTaskCount(),
                this.isShutdown(),
                this.isTerminated());
    }
}
