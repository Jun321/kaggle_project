/*
 * 
 * BackDateTask	Jul 25, 2016
 * Copyright (c) 2006 State Street Technology(Zhejiang) Co.,Ltd.
 * All rights reserved.
 * 
 */
package backDate;

import java.util.UUID;
import java.util.concurrent.TimeUnit;

/**
 * @Description: TODO
 * @author e604294
 */

public class BackDateTask implements Runnable{
    protected String fund = null;
    protected String backdate = null;
    private long runningTime = 0;
    private UUID uuid = UUID.randomUUID();
    
    public BackDateTask(String fund, String backdate, int runningTime){
        this.fund = fund;
        this.backdate = backdate;
        this.runningTime = runningTime;
    }
    
    @Override
    public void run() {
        try {
            System.out.println(String.format("fund:%s backDate:%s --- start", this.fund, this.backdate));
            TimeUnit.SECONDS.sleep(runningTime);
            System.out.println(String.format("fund:%s backDate:%s --- complete", this.fund, this.backdate));
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    
    public String getFund(){
        return this.fund;
    }
    
    public String getBackdate(){
        return this.backdate;
    }
    
    public long getRunningTime(){
        return this.runningTime;
    }
    
    public UUID getUUID(){
        return this.uuid;
    }
}
