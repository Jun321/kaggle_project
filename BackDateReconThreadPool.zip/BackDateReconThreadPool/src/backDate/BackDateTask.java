/*
 * 
 * BackDateTask	Jul 25, 2016
 * Copyright (c) 2006 State Street Technology(Zhejiang) Co.,Ltd.
 * All rights reserved.
 * 
 */
package backDate;

import java.util.concurrent.TimeUnit;

/**
 * @Description: TODO
 * @author e604294
 */

public class BackDateTask implements Runnable{
    int backdate = 0;
    public BackDateTask(int backdate){
        this.backdate = backdate;
    }
    
    @Override
    public void run() {
        try {
            TimeUnit.SECONDS.sleep(backdate);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    
    public int getBackdateNum(){
        return backdate;
    }

}
