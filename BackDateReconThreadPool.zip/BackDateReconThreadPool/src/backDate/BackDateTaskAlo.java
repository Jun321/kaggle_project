/*
 * 
 * BackDateTaskAlo	Jul 25, 2016
 * Copyright (c) 2006 State Street Technology(Zhejiang) Co.,Ltd.
 * All rights reserved.
 * 
 */
package backDate;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

/**
 * @Description: TODO
 * @author e604294
 */

public final class BackDateTaskAlo {
    private static Map<String, Integer> tasksComplexity = new HashMap<String, Integer>();
    private static ReentrantReadWriteLock rwl = new ReentrantReadWriteLock();
    private static Lock r = rwl.readLock();
    private static Lock w = rwl.writeLock();
    
    public static final Integer get(String key){
        r.lock();
        try{
            return tasksComplexity.get(key);
        } finally {
            r.unlock();
        }
    }
    
    public static final Integer put(String key, Integer value){
        w.lock();
        try{
            return tasksComplexity.put(key, value);
        } finally {
            w.unlock();
        }
    }
    
    public static final Integer remove(String key){
        w.lock();
        try{
            return tasksComplexity.remove(key);
        } finally {
            w.unlock();
        }
    }
}
