/*
 * 
 * BackDatedController	Jul 27, 2016
 * Copyright (c) 2006 State Street Technology(Zhejiang) Co.,Ltd.
 * All rights reserved.
 * 
 */
package backDate.controller;

import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import backDate.BackDateTask;
import backDate.BackDatedThreadPool;
import backDate.alo.BackDateTaskAlo;
import backDate.alo.Task;

/**
 * @Description: TODO
 * @author e604294
 */

public final class BackDatedController {
    private static final Queue<BackDateTask> taskList = new ConcurrentLinkedQueue<BackDateTask>();
    private static final Queue<Task> tasks= new ConcurrentLinkedQueue<Task>();
    private static final ReentrantReadWriteLock rwl = new ReentrantReadWriteLock();
    private static final Lock r = rwl.readLock();
    private static final Lock w = rwl.writeLock();
    
    private BackDatedController(){}
    
    public static final void addTask(BackDateTask task) {
        w.lock();
        try{
            taskList.add(task);
            BackDateTaskAlo.addTask(task.getFund(), task.getBackdate(), task.getUUID(), tasks);
            if (BackDatedThreadPool.isActivePattern()){
                BackDateTaskAlo.submitToPool(tasks);
            }
        }
        finally{
            w.unlock();
        }
    }
    
}
