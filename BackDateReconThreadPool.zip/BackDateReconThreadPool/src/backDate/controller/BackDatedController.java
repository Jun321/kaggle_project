/*
 * 
 * BackDatedController	Jul 27, 2016
 * Copyright (c) 2006 State Street Technology(Zhejiang) Co.,Ltd.
 * All rights reserved.
 * 
 */
package backDate.controller;

import backDate.BackDateTask;
import backDate.BackDatedThreadPool;
import backDate.alo.BackDateTaskAlo;

/**
 * @Description: TODO
 * @author e604294
 */

public class BackDatedController {
    private BackDatedController(){}
    
    public static final void addTask(BackDateTask task) {
        BackDateTaskAlo.addTaskMap(task.getFund(), task.getBackdate());
        if (BackDatedThreadPool.isActivePattern())
            BackDateTaskAlo.submitToThreadPool();
            
    }
    
}
