/*
 * 
 * BackDatedController	Jul 27, 2016
 * Copyright (c) 2006 State Street Technology(Zhejiang) Co.,Ltd.
 * All rights reserved.
 * 
 */
package backDate.controller;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReentrantLock;
import backDate.BackDateTask;
import backDate.BackDatedThreadPool;
import backDate.alo.BackDateTaskAlo;
import backDate.alo.Record;
import backDate.alo.TaskTicket;

/**
 * @Description: TODO
 * @author e604294
 */

public final class BackDatedController extends Thread{
    private static final List<TaskTicket> ticketList = new LinkedList<TaskTicket>();
    private static final List<Record> records= new ArrayList<Record>();
    
    private static final ReentrantLock lock = new ReentrantLock();
    
    private static final BackDatedController INSTANCE = new BackDatedController();
    
    private BackDatedController(){}
    
    public static BackDatedController getInstance(){
        return INSTANCE;
    }
    
    public static final void addTask(BackDateTask task) {
        lock.lock();
        try{
            TaskTicket ticket = BackDateTaskAlo.addTask(task, records);
            ticketList.add(ticket);
            
            submitTasks();
        }
        finally{
            lock.unlock();
        }
    }
    
    public static final void notifyComplete(BackDateTask task){
        lock.lock();
        try{
            setRecords(task);
            
            submitTasks();
        }
        finally{
            lock.unlock();
        }
    }
    
    private static final void setRecords(BackDateTask task){
        long runTime = task.getRunningTime();
        TaskTicket ticket = null;
        for (TaskTicket t : ticketList){
            if (t.getCallable().getUUID().equals(task.getUUID())){
                t.getRecord().addRunTime(runTime);
                ticket = t;
                break;
            }
        }
        ticketList.remove(ticket);
    }
    
    private static final void submitTasks(){
        ArrayList<BackDateTask> res = BackDateTaskAlo.getSubmitTasks(ticketList);
        if (res != null){
            for (BackDateTask t : res)
                BackDatedThreadPool.getInstance().execute(t);
        }
    }
    
    private static final String getInfoAboutRecordsAndTask(){
        StringBuilder sb = new StringBuilder();
        sb.append("TaskList:[\n");
        for (TaskTicket t : ticketList){
            sb.append("(")
            .append("State: ")
            .append(t.getState())
            .append(" Fund: ")
            .append(t.getCallable().getFund())
            .append(" PendingTime: ")
            .append(t.getPendingMinutes())
            .append(")")
            .append("\n");
        }
        sb.append("]");
        sb.append("Records:[\n");
        for (Record t : records){
            sb.append("(")
            .append("Fund: ")
            .append(t.getFund())
            .append(" BackDate: ")
            .append(t.getBackDate())
            .append(" RunTimeSize: ")
            .append(t.getRuntimes())
            .append("{")
            .append(t.getTimesInfo())
            .append("}")
            .append(")")
            .append("\n");
        }
        sb.append("]");
        return sb.toString();
    }
    
    @Override
    public void run() {
        while(true){
            lock.lock();
            try{
                if (BackDateTaskAlo.ifChangeToLearn(records)){
                    System.out.println("Transforming mode into LearningMode.");
                    BackDateTaskAlo.changeModeToLearn(records);
                }
                System.out.println(getInfoAboutRecordsAndTask());
//                System.out.println(BackDatedThreadPool.getInstance().getThreadPoolInfo());
            }
            finally{
                lock.unlock();
            }
            try {
                TimeUnit.SECONDS.sleep(3);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
    
}
