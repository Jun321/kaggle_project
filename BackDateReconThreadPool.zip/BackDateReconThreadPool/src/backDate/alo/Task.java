/*
 * 
 * BackDateTask	Jul 27, 2016
 * Copyright (c) 2006 State Street Technology(Zhejiang) Co.,Ltd.
 * All rights reserved.
 * 
 */
package backDate.alo;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.UUID;

/**
 * @Description: TODO
 * @author e604294
 */

public class Task{
    public static final int QUEUESIZE = 5;
    
    String fund;
    ArrayList<String> bacDate;
    
    LinkedList<TaskTicket> tickets = new LinkedList<TaskTicket>();
    
    LinkedList<Long> runTimes = new LinkedList<Long>();
    float runTimeAverage = Float.NaN;
    LocalDateTime createTime;
    
    Priority priority = new Priority();
    
    public Task(String fund, ArrayList<String> bacDate, UUID uuid){
        this.fund = fund;
        this.bacDate = bacDate;
        this.createTime = LocalDateTime.now();
        this.tickets.add(new TaskTicket(uuid));
    }
    
    public void addRunTime(long time){
        if(runTimes.size() != Task.QUEUESIZE){
            runTimes.add(time);
            runTimeAverage = getAverage(runTimes);
        }else{
            runTimes.poll();
            runTimes.add(time);
            runTimeAverage = getAverage(runTimes);
        }
            
    }
    
    public void addTicket(UUID uuid){
        this.tickets.add(new TaskTicket(uuid));
    }
    
    public boolean removeTicket(UUID uuid){
        for (TaskTicket t : tickets){
            if (uuid.equals(t.uuid))
                return tickets.remove(t);
        }
        return false;
    }
    
    public LinkedList<TaskTicket> getTaskTickets(){
        return tickets;
    }
    
    public Priority getPriority(){
        return this.priority;
    }
    
    public ArrayList<String> getBackDate(){
        return bacDate;
    }
    
    public float getRunTimeAverage(){
        return runTimeAverage;
    }
    
    public float getBacDatesSize(){
        return bacDate.size();
    }
    
    public String getFund(){
        return fund;
    }
    
    public boolean isSame(String fund, ArrayList<String> backdate){
        return fund.equals(this.fund) && backdate.stream().allMatch(s -> this.bacDate.contains(s));
    }
    
    private float getAverage(LinkedList<Long> runTimes){
        Long sum = 0l;
        for (Long num : runTimes)
            sum += num;
        return (float)sum / (float)runTimes.size();
    }
}
