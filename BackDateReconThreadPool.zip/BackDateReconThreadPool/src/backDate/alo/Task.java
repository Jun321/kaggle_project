/*
 * 
 * BackDateTask	Jul 27, 2016
 * Copyright (c) 2006 State Street Technology(Zhejiang) Co.,Ltd.
 * All rights reserved.
 * 
 */
package backDate.alo;

import java.util.LinkedList;

/**
 * @Description: TODO
 * @author e604294
 */

public class Task{
    String fund;
    LinkedList<String> bacDate;
    LinkedList<Long> runTimes = new LinkedList<Long>();
    float runTimeAverage = Float.NaN;
    
    public Task(String fund, LinkedList<String> bacDate){
        this.fund = fund;
        this.bacDate = bacDate;
    }
    
    public void addRunTime(long time){
        if(runTimes.size() != BackDateTaskAlo.QUEUESIZE){
            runTimes.add(time);
            runTimeAverage = getAverage(runTimes);
        }else{
            runTimes.poll();
            runTimes.add(time);
            runTimeAverage = getAverage(runTimes);
        }
            
    }
    
    public LinkedList<String> getBackDate(){
        return bacDate;
    }
    
    public float getRunTimeAverage(){
        return runTimeAverage;
    }
    
    public float getBacDatesSize(){
        return bacDate.size();
    }
    
    public String getFund(){
        return fund;
    }
    
    public boolean isSame(String fund, LinkedList<String> backdate){
        return fund.equals(this.fund) && backdate.stream().allMatch(s -> this.bacDate.contains(s));
    }
    
    private float getAverage(LinkedList<Long> runTimes){
        Long sum = 0l;
        for (Long num : runTimes)
            sum += num;
        return (float)sum / (float)runTimes.size();
    }
    
}
