/*
 * 
 * TaskState	Jul 28, 2016
 * Copyright (c) 2006 State Street Technology(Zhejiang) Co.,Ltd.
 * All rights reserved.
 * 
 */
package backDate.alo;

/**
 * @Description: TODO
 * @author e604294
 */

public enum TaskState {
    TASKPENDING,
    TASKSUBMIT
}
