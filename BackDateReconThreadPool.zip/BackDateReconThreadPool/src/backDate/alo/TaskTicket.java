/*
 * 
 * taskTicket	Jul 29, 2016
 * Copyright (c) 2006 State Street Technology(Zhejiang) Co.,Ltd.
 * All rights reserved.
 * 
 */
package backDate.alo;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import backDate.BackDateTask;

/**
 * @Description: TODO
 * @author e604294
 */

public class TaskTicket {
    Record record;
    BackDateTask callable;
    
    TaskState state = TaskState.TASKPENDING;
    LocalDateTime createTime;
    LocalDateTime conditionTime;
    long pendingMinutes = 0;
    
    public TaskTicket(Record t, BackDateTask cab){
        this.createTime = LocalDateTime.now();
        this.conditionTime = LocalDateTime.now();
        this.record = t;
        this.callable = cab;
    }
    
    public void setState(TaskState state){
        this.state = state;
    }
    
    public void setConditionTime(LocalDateTime t){
        this.conditionTime = t;
    }
    
    public TaskState getState(){
        return this.state;
    }
    
    public long getPendingMinutes(){
        return pendingMinutes = createTime.until(conditionTime, ChronoUnit.MINUTES);
    }
    
    public Record getRecord(){
        return this.record;
    }
    
    public BackDateTask getCallable(){
        return this.callable;
    }
}
