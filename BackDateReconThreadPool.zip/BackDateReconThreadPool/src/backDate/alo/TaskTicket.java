/*
 * 
 * taskTicket	Jul 29, 2016
 * Copyright (c) 2006 State Street Technology(Zhejiang) Co.,Ltd.
 * All rights reserved.
 * 
 */
package backDate.alo;

import java.util.UUID;

/**
 * @Description: TODO
 * @author e604294
 */

public class TaskTicket {
    TaskState state = TaskState.TASKINITIAL;
    UUID uuid;
    
    public TaskTicket(UUID uuid){
        this.uuid = uuid;
    }
    
    public TaskState getState(){
        return this.state;
    }
    
    public UUID getUUID(){
        return this.uuid;
    }
    
    public void setState(TaskState state){
        this.state = state;
    }
}
