/*
 * 
 * Priority	Jul 27, 2016
 * Copyright (c) 2006 State Street Technology(Zhejiang) Co.,Ltd.
 * All rights reserved.
 * 
 */
package backDate.alo;

/**
 * @Description: TODO
 * @author e604294
 */

public class Priority{
    float priOfBackDateSize = Float.NaN;
    float priOfRunningTime = Float.NaN;
    
    public float getPriOfBackDateSize() {
        return priOfBackDateSize;
    }
    public void setPriOfBackDateSize(float priOfBackDateSize) {
        this.priOfBackDateSize = priOfBackDateSize;
    }
    public float getPriOfRunningTime() {
        return priOfRunningTime;
    }
    public void setPriOfRunningTime(float priOfRunningTime) {
        this.priOfRunningTime = priOfRunningTime;
    }
    public float getPrioritynum(boolean isSize){
        return isSize ? priOfBackDateSize : priOfRunningTime;
    }
}