/*
 * 
 * BackDateTaskAlo	Jul 25, 2016
 * Copyright (c) 2006 State Street Technology(Zhejiang) Co.,Ltd.
 * All rights reserved.
 * 
 */
package backDate.alo;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.stream.Collectors;

import backDate.BackDateTask;
import backDate.BackDatedThreadPool;


/**
 * @Description: TODO
 * @author e604294
 */

public final class BackDateTaskAlo {
    private static AtomicBoolean isLearningPattern = new AtomicBoolean(false);
    private static final float SIZELINE_MAX = 0.9f;
    private static final float SIZELINE_MIN = 0.1f;
    private static float SIZELINE = 0.0f;
    private static final float CUTLINE = 0.2f;
    private static final long PENDINGMINS = 5;
    
    public static final boolean ifChangeToLearn(List<Record> records){
        int recordNum = 0;
        if (records.size() >= 20){
            for (Record r : records){
                int tmp = r.getRuntimes();
                if (tmp >= 1)
                    recordNum++;
                if (tmp == 0)
                    return false;
            }
            return !isLearningPattern.get() && (float)recordNum/records.size() > 0.8f;
        }
        return false;
    }
    
    public static void changeModeToLearn(List<Record> records) {
        isLearningPattern.set(true);
        calPriorities(records);
    }
    
    public static final TaskTicket addTask(BackDateTask callable, List<Record> records){
        String backDate = callable.getBackdate();
        String fund = callable.getFund();
        ArrayList<String> backdate = new ArrayList<String>(Arrays.asList(backDate.trim().split(",")));
        Optional<Record> op = records.stream().filter(s -> s.isSame(fund, backdate)).findFirst();
        TaskTicket ticket;
        if (!op.isPresent()){
            Record record = new Record(fund, backdate);
            ticket = new TaskTicket(record, callable);
            records.add(record);
            isLearningPattern.set(false);
            calPriorities(records);
            System.out.println("Setting Learning Pattern into false...");
        }
        else{
            ticket = new TaskTicket(op.get(), callable);
        }
        return ticket;
    }
    
    private static final void calPriorities(List<Record> tasks){
        boolean pattern = isLearningPattern.get();
        float[] minMax = getMinMax(tasks, !pattern);
        boolean isZeroDelta = minMax[1] - minMax[0] == 0;
        for (Record t : tasks)
            setPriorities(t, pattern, isZeroDelta, minMax);
    }
    
    private static final float[] getMinMax(List<Record> tasks, boolean isSize){
        float min = Float.MAX_VALUE, max = Float.MIN_VALUE;
        for (Record t : tasks){
            float tmp = isSize ? t.getBacDatesSize() : t.getRunTimeAverage();
            if (tmp >  max)
                max = tmp;
            if (tmp < min)
                min = tmp;
        }
        float[] res = {min, max};
        return res;
            
    }
    
    private static final void setPriorities(Record t, boolean pattern, boolean isZeroDelta, float[] minMax){
        if (isZeroDelta){
            if (pattern)
                t.getPriority().setPriOfRunningTime(1.0f);
            else
                t.getPriority().setPriOfBackDateSize(1.0f);
            return;
        }
        if (pattern)
            t.getPriority().setPriOfRunningTime((t.getRunTimeAverage() - minMax[0]) / (minMax[1] - minMax[0]));
        else
            t.getPriority().setPriOfBackDateSize((t.getBacDatesSize() - minMax[0]) / (minMax[1] - minMax[0]));
    }
    
    public static final ArrayList<BackDateTask> getSubmitTasks(List<TaskTicket> tickets) {
        //Get pending TaskTicket.
        List<TaskTicket> t_pend = filterTickets(tickets, TaskState.TASKPENDING);
        
        if (t_pend != null){
            //Get submit TaskTicket.
            List<TaskTicket> t_run = filterTickets(tickets, TaskState.TASKSUBMIT);
            
            //Get heavy and simple submit num in submit Record.
            int heavy_num = 0, simple_num = 0;
            boolean flag = isLearningPattern.get();
            
            //Calculate SIZELINE.
            setSizeLine(tickets, !flag);
            if (t_run != null){
                for (TaskTicket r : t_run){
                    if (r.getRecord().getPriority().getPrioritynum(!flag) > CUTLINE)
                        heavy_num++;
                    else
                        simple_num++;
                }
            }
            int max_poolSize = BackDatedThreadPool.getInstance().getMaxPoolSize();
            int[] submit_num = getSubmitNum(max_poolSize, SIZELINE, simple_num, heavy_num);
            System.out.println("submit_num: " + submit_num[0] + ", " + submit_num[1]);
            int submit_simple = submit_num[0];
            int submit_heavy = submit_num[1];
            
            //According to the num of simple and heavy, get specific tasks in pending tasks
            if (submit_heavy > 0 || submit_simple > 0){
                ArrayList<BackDateTask> res = sortTasksToList(submit_simple, submit_heavy, t_pend, !flag);
                return res;
            }
        }
        return null;
    }
    
    private static final List<TaskTicket> filterTickets(List<TaskTicket> tickets, TaskState state){
        List<TaskTicket> res = tickets.stream().filter(s -> s.getState() == state).collect(Collectors.toList());
        return res.isEmpty() ? null : res;
    }
    
    private static void setSizeLine(List<TaskTicket> tickets, boolean isSize) {
        float s_priority = 0.0f, h_priority = 0.0f;
        int simple_num = 0, heavy_num = 0, max_num = BackDatedThreadPool.getInstance().getMaxPoolSize();
        for (TaskTicket t : tickets){
            float priority = t.getRecord().getPriority().getPrioritynum(isSize);
            if (priority > CUTLINE){
                heavy_num++;
                h_priority += priority;
            }else{
                simple_num++;
                s_priority += priority;
            }
        }
        float res = 0.0f;
        float cut_ratio = getHeavySimpleRatio(heavy_num, simple_num, h_priority, s_priority, max_num);
        int s_rule_num = Math.round(max_num * cut_ratio);
        int h_rule_num = max_num - s_rule_num;
        
        if (simple_num + heavy_num <= max_num){
            res = heavy_num == 0 ? (simple_num == 0 ? 0.0f : 1.0f) : (float)simple_num / (simple_num + heavy_num);
        }
        else if (simple_num >= s_rule_num && heavy_num >= h_rule_num){
            res = cut_ratio;
        }
        else{
            int s = s_rule_num - simple_num > 0 ? simple_num : max_num - heavy_num;
            int h = h_rule_num - heavy_num > 0 ? heavy_num : max_num - simple_num;
            res = (float)s / (s + h);
        }
      
        SIZELINE = res > SIZELINE_MAX ? SIZELINE_MAX : res < SIZELINE_MIN ? SIZELINE_MIN : res;
    }
    
    private static float getHeavySimpleRatio(int heavy_num, int simple_num, float h_priority, float s_priority, int max_num){
        float heavy_ave = heavy_num > 0 ? h_priority / heavy_num : 0.0f;
        float simple_ave = simple_num > 0 ? s_priority / simple_num : 0.0f;
        float cut_ratio = heavy_ave > 0 || simple_ave > 0 ? simple_ave / (simple_ave + heavy_ave) : 0.0f;
        return cut_ratio;
    }
    
    private static int[] getSubmitNum(int max_size, float ratio, int simple_run, int heavy_run){
        int simple_rule = Math.round(max_size * ratio);
        int heavy_rule = max_size - simple_rule;
        int ava_size = max_size - simple_run - heavy_run;
        int submit_simple = 0, submit_heavy = 0;
        if (ava_size > 0){
            int s_delta = simple_rule - simple_run;
            int h_delta = heavy_rule - heavy_run;
            submit_simple = ava_size >= s_delta ? s_delta > 0 ? s_delta : 0 : ava_size;
            submit_heavy = ava_size >= h_delta ? h_delta > 0 ? h_delta : 0 : ava_size;
        }
        return new int[]{submit_simple, submit_heavy};
    }
    
    private static final ArrayList<BackDateTask> sortTasksToList(int simple, int heavy, List<TaskTicket> records, boolean isSize){
        ArrayList<BackDateTask> res = new ArrayList<BackDateTask>();
        ArrayList<TaskTicket> simple_penTicket = new ArrayList<TaskTicket>();
        ArrayList<TaskTicket> heavy_penTicket = new ArrayList<TaskTicket>();
        LinkedList<TaskTicket> resStack = new LinkedList<TaskTicket>();
        int simple_penLen = 0;
        int heavy_penLen = 0;
        
        //Get pending tasks simple and heavy num. Then package them into arraylist.
        for (TaskTicket r : records){
            if (r.getRecord().getPriority().getPrioritynum(isSize) > CUTLINE){
                heavy_penTicket.add(r);
                heavy_penLen ++;
            }
            else{
                simple_penTicket.add(r);
                simple_penLen ++;
            }
        }
        
        backDateSort(simple_penTicket, resStack, res, simple_penLen, simple, isSize);
        backDateSort(heavy_penTicket, resStack, res, heavy_penLen, heavy, isSize);
        
        return res.size() == 0 ? null : res;
    }
    
    private static final void backDateSort(ArrayList<TaskTicket> tickets, LinkedList<TaskTicket> stack, ArrayList<BackDateTask> res, int penLen, int resLen, boolean isSize){
        if (penLen > resLen){
            if (resLen != 0){
                int start = 0;
                int end = 0;
                int endnum = 0;
                
                //Sort by priority desc
                Collections.sort(tickets, (a, b) -> a.getRecord().getPriority().getPrioritynum(isSize) < b.getRecord().getPriority().getPrioritynum(isSize) ?
                        1 : a.getRecord().getPriority().getPrioritynum(isSize) == b.getRecord().getPriority().getPrioritynum(isSize) ? 0 : -1);
                
                //Rule as same time set in localdatetime
                setConditionTime(tickets);
                
                //Group tickets in 5 mins and use stack LIFO to get the same time period and priority sort in sc.
                //Then get the exact res_num according given num.
                while(endnum < penLen){
                    end += PENDINGMINS;
                    for (TaskTicket t : tickets){
                        if (t.getPendingMinutes() >= start && t.getPendingMinutes() < end){
                            endnum++;
                            stack.push(t);
                        }
                    }
                    start += PENDINGMINS;
                }
                for (int i = 0; i < resLen; i++){
                    TaskTicket ticket = stack.pop();
                    ticket.setState(TaskState.TASKSUBMIT);
                    res.add(ticket.getCallable());
                }
                stack.clear();
            }
        }else{
            for (TaskTicket t : tickets){
                t.setState(TaskState.TASKSUBMIT);
                res.add(t.getCallable());
            }
        }
    }
    
    private static final void setConditionTime(ArrayList<TaskTicket> tickets){
        for (TaskTicket t : tickets)
            t.setConditionTime(LocalDateTime.now());
    }
}
