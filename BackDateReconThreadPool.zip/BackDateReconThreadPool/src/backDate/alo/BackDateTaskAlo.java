/*
 * 
 * BackDateTaskAlo	Jul 25, 2016
 * Copyright (c) 2006 State Street Technology(Zhejiang) Co.,Ltd.
 * All rights reserved.
 * 
 */
package backDate.alo;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;


/**
 * @Description: TODO
 * @author e604294
 */

public final class BackDateTaskAlo {
    private static Map<Task, Priority> tasksMap = new ConcurrentHashMap<Task, Priority>();
    public static final int QUEUESIZE = 5;
    
    
    public static final void addTaskMap(String backDate, String fund){
        LinkedList<String> backdate = new LinkedList<String>(Arrays.asList(backDate.trim().split(",")));
        Optional<Entry<Task, Priority>> op = tasksMap.entrySet().stream().filter(s -> s.getKey().isSame(fund, backdate)).findFirst();
        if(!op.isPresent()){
            Task t = new Task(fund, backdate);
            tasksMap.put(t, calPriority(t));
        }
    }
    
    public static final void setTasksMap(Task task, long time){
        task.addRunTime(time);
//        LinkedList<String> backdate = task.getBackDate();
//        Optional<Entry<Task, Priority>> op = tasksMap.entrySet().stream().filter(s -> s.getKey().isSame(task.fund, backdate)).findFirst();
//        if(op.isPresent())
//            op.get().getKey().addRunTime(time);
    }
    
    public static final void submitToThreadPool(){
        
    }
    
    private static final Priority calPriority(Task task){
        Priority priority = new Priority();
        priority.setPriOfBackDateSize(getMinMax(task.getBacDatesSize(), true));
        if (!hasNew())
            priority.setPriOfRunningTime(getMinMax(task.getRunTimeAverage(), false));
        return priority;
    }
    
    private static final float getMinMax(float x, boolean isSize){
        float min = Float.MAX_VALUE, max = Float.MIN_VALUE;
        for (Task t : tasksMap.keySet()){
            float tmp = isSize ? t.getBacDatesSize() : t.getRunTimeAverage();
            if (tmp >  max)
                max = tmp;
            if (tmp < min)
                min = tmp;
        }
        return (max - x) / (max - min);
            
    }
    
    private static boolean hasNew(){
        Optional<Entry<Task, Priority>> op = tasksMap.entrySet().stream().filter(s -> s.getKey().getRunTimeAverage() == Float.NaN).findFirst();
        return op.isPresent();
    }
}
