/*
 * 
 * BackDateTaskAlo	Jul 25, 2016
 * Copyright (c) 2006 State Street Technology(Zhejiang) Co.,Ltd.
 * All rights reserved.
 * 
 */
package backDate.alo;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.Map;
import java.util.Queue;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.stream.Stream;


/**
 * @Description: TODO
 * @author e604294
 */

public final class BackDateTaskAlo {
    private static AtomicBoolean isLearningPattern = new AtomicBoolean(false);
    private static final float CUTLINE = 0.2f;
    
    public static final void addTask(String fund, String backDate, UUID uuid, Queue<Task> tasks){
        ArrayList<String> backdate = new ArrayList<String>(Arrays.asList(backDate.trim().split(",")));
        Optional<Task> op = tasks.stream().filter(s -> s.isSame(fund, backdate)).findFirst();
        if (!op.isPresent()){
            Task t = new Task(fund, backdate, uuid);
            tasks.add(t);
            isLearningPattern.set(false);
            calPriorities(tasks);
        }
        else{
            op.get().addTicket(uuid);
        }
    }
    
    public static final void submitToPool(Queue<Task> tasks) {
        Task[] t1 = getRunningTasks(tasks);
        Task[] t2 = getPendingTasks(tasks);
        long heavy_num = 0, simple_num = 0;
        boolean flag = isLearningPattern.get();
        heavy_num = (new ArrayList<Task>(Arrays.asList(t1))).stream().filter(s -> s.getPriority().getPrioritynum(!flag) > CUTLINE).count();
        simple_num = t1.length - heavy_num;
    }
    
    public static final void setTasksMap(Task task, long time){
        task.addRunTime(time);
//        LinkedList<String> backdate = task.getBackDate();
//        Optional<Entry<Task, Priority>> op = tasksMap.entrySet().stream().filter(s -> s.getKey().isSame(task.fund, backdate)).findFirst();
//        if(op.isPresent())
//            op.get().getKey().addRunTime(time);
    }
    
    private static final void calPriorities(Queue<Task> tasks){
        boolean pattern = isLearningPattern.get();
        float[] minMax = getMinMax(tasks, !pattern);
        for (Task t : tasks){
            if (pattern)
                t.getPriority().setPriOfRunningTime((t.getRunTimeAverage() - minMax[0]) / (minMax[1] - minMax[0]));
            else
                t.getPriority().setPriOfBackDateSize((t.getBacDatesSize() - minMax[0]) / (minMax[1] - minMax[0]));
            t.getTaskTickets().stream().filter(s -> s.state == TaskState.TASKINITIAL).forEach(s -> s.setState(TaskState.TASKPENDING));
        }
        
    }
    
    private static final float[] getMinMax(Queue<Task> tasks, boolean isSize){
        float min = Float.MAX_VALUE, max = Float.MIN_VALUE;
        for (Task t : tasks){
            float tmp = isSize ? t.getBacDatesSize() : t.getRunTimeAverage();
            if (tmp >  max)
                max = tmp;
            if (tmp < min)
                min = tmp;
        }
        float[] res = {min, max};
        return res;
            
    }
    
    private static final Task[] getRunningTasks(Queue<Task> tasks){
        Stream<Task> res = tasks.stream().filter(s -> s.tickets.stream().filter(x -> x.state == TaskState.TASKSUBMIT).findFirst().isPresent());
        if (res.findFirst().isPresent())
            return (Task[])res.toArray();
        return null;
    }
    
    private static final Task[] getPendingTasks(Queue<Task> tasks) {
        Stream<Task> res = tasks.stream().filter(s -> s.tickets.stream().filter(x -> x.state == TaskState.TASKPENDING).findFirst().isPresent());
        if (res.findFirst().isPresent())
            return (Task[])res.toArray();
        return null;
    }
    
}
