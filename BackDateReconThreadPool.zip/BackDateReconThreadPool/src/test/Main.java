/*
 * 
 * Main	Jul 25, 2016
 * Copyright (c) 2006 State Street Technology(Zhejiang) Co.,Ltd.
 * All rights reserved.
 * 
 */
package test;

/**
 * @Description: TODO
 * @author e604294
 */

public class Main {
    public static void main(String args[]){
        A a = new A();
        System.out.print((B)a);
    }
}

class A{
    String a = "123";
}

class B extends A{
    String b = "12312312";
}