/*
 * 
 * Main	Jul 25, 2016
 * Copyright (c) 2006 State Street Technology(Zhejiang) Co.,Ltd.
 * All rights reserved.
 * 
 */
package test;

/**
 * @Description: TODO
 * @author e604294
 */

public class Main {
    public static void main(String args[]){
        System.out.println((int)1.1);
    }
}
