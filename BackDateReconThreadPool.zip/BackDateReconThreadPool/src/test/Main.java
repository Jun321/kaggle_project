/*
 * 
 * Main	Jul 25, 2016
 * Copyright (c) 2006 State Street Technology(Zhejiang) Co.,Ltd.
 * All rights reserved.
 * 
 */
package test;

import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedList;

/**
 * @Description: TODO
 * @author e604294
 */

public class Main {
    public static void main(String args[]){
        HashMap<A, String> s = new HashMap<A, String>();
        
        A a = new A();
        A a1 = new A();
        a1.c = "123333333";
        s.put(a, "123");
        s.put(a1, "321");
        System.out.println(s.put(a1, "321"));
        System.out.print(s.entrySet().stream().filter(x -> x.getKey().c.equals("123")).findAny().isPresent());
    }
}

class A{
    String a = "123";
    LinkedList<String> s = new LinkedList<String>(Arrays.asList("123","123"));
    String c = "123";
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((a == null) ? 0 : a.hashCode());
        result = prime * result + ((s == null) ? 0 : s.hashCode());
        return result;
    }
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        A other = (A) obj;
        if (a == null) {
            if (other.a != null)
                return false;
        } else if (!a.equals(other.a))
            return false;
        if (s == null) {
            if (other.s != null)
                return false;
        } else if (!s.equals(other.s))
            return false;
        return true;
    }
    
}

class B extends A{
    String b = "12312312";
}