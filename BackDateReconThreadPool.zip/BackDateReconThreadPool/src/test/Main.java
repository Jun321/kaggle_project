/*
 * 
 * Main	Jul 25, 2016
 * Copyright (c) 2006 State Street Technology(Zhejiang) Co.,Ltd.
 * All rights reserved.
 * 
 */
package test;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import backDate.BackDateTask;
import backDate.controller.BackDatedController;

/**
 * @Description: TODO
 * @author e604294
 */

public class Main {
    static Random rn = new Random();
    public static void main(String args[]){
        BackDatedController controller = BackDatedController.getInstance();
        controller.start();
        
        List<BackDateTask> l = new ArrayList<BackDateTask>();
        
        for (int i = 0; i < 20; i++){
            BackDateTask t = getTask();
            l.add(t);
            BackDatedController.addTask(t);
        }
        
        try {
            TimeUnit.SECONDS.sleep(4);
            System.out.println("----------------------sleepdone-------------------------");
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        for (BackDateTask t : l){
            if (t.getBackdate().split(",").length > 4)
                BackDatedController.addTask(t);
        }
        
    }
    
    
    static BackDateTask getTask(){
        String[] tmp = getBackDatedAndTime();
        int time = Integer.valueOf(Math.round(Float.valueOf(tmp[0])));
        String bacDate = tmp[1];
        BackDateTask t = new BackDateTask(getFund(), bacDate, time);
        return t;
    }
    
    static String[] getBackDatedAndTime(){
        String[] s = new String[2];
        int min = 1, max = 10;
        int time = rn.nextInt(max - min + 1) + min;
        s[0] = String.valueOf((float)time + Math.random() * (rn.nextInt(4) - 1));
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < time; i++){
            sb.append(randomString()).append(",");
        }
        s[1] = sb.substring(0, sb.length() - 1);
        return s;
    }
    
    static String getFund(){
        return randomString();
    }
    
    static String randomString(){
        int min = 1, max = 10;
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 3; i++){
            sb.append(rn.nextInt(max - min + 1) + min);
        }
        return sb.toString();
    }
}

